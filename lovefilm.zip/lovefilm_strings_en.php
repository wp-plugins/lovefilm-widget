<?php
define('LOVEFILM_STR_ADMIN_CONTEXTUAL_DISPLAY_ARTICLE_LINK', 'Earn more by displaying a sign up message at the bottom of an article. <a href="http://www.lovefilm.com/partnership/widgets#articlelinks" target="_blank">Learn more</a>.');
define('LOVEFILM_STR_ADMIN_WIDGET_CONTEXT', 'Would you like to display the latest Films or Games?');
define('LOVEFILM_STR_ADMIN_WIDTH_TYPE', "Selected either a specific fixed width or leave as 'fluid' to automatically select the most appropriate size.");
define('LOVEFILM_STR_ADMIN_SHARE_LOVE', 'Enter your LOVEFiLM Share the love code. <a href="http://www.lovefilm.com/partnership/widgets#sharethelove" target="_blank">Learn more</a>.');
define('LOVEFILM_STR_ADMIN_AFFILIATE_CODE', 'Enter your LOVEFiLM Affiliate Code. <a href="http://www.lovefilm.com/partnership/widgets#affiliatecode" target="_blank">Learn more</a>.');