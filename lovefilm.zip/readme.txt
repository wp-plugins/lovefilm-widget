=== LOVEFiLM Widget ===
Contributors: LOVEFiLM-widgets
Requires at least: 2.8.0
Tested up to: 3.1.0
Tags: Film, Films, Games, Media, Affiliate
Stable Tag: 2.0

This plugin allows you to add the official LOVEFiLM widget to the sidebar of your Wordpress blog.

== Description ==

Easily and quickly integrate the LOVEFiLM Widget into your website. This plugin enables you to monetize your website through the use of LOVEFiLM's Affiliate or Share the LOVE Program. By selecting either program you will earn referral fees for each LOVEFiLM sign up through your website. 
The plugin displays the latest and most popular film or games titles and comes with customisable width and colour themes.
By popular demand, the Plugin now features contextualisation. An individual title can be selected and featured within the widget.  Support for a simple 'sign up' message at the footer of each article is now supported increasing sign up potential.
This plugin fully supports [LOVEFiLM.com](http://www.lovefilm.com/) at the present time with other LOVEFiLM territories being offered in the near future.

== Installation ==

[Watch how to install and set up the widget](http://www.lovefilm.com/partnership/widgets#installvideo) or follow the steps below:

1.	Install the plugin from within the Dashboard or upload the lovefilm folder and all its contents to the /wp-content/plugins/ directory
2.	Activate the plugin through the 'Plugins' menu in WordPress
3.	Drag and drop the widget onto your sidebar. Go to 'appearance' then 'widgets'
4.	Edit your preferences in the 'LOVEFiLM Widget' settings panel


